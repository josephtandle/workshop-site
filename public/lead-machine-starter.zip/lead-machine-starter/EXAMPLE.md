# What a real run looks like

This is one full cycle for an example business, so you know what to expect.
Every name below is invented.

## The setup (once)

> **You:** set me up
> **It:** What do you sell, and what does it cost?
> **You:** 8-week breathwork coaching for burned-out founders, $1,200
> ...four more questions, then it writes MY-BUSINESS.md and you never repeat yourself.

## The daily 10 minutes

> **You:** hunt 4
> **It:** Found 4 people with proof, written to data/candidates.csv:
> 1. Sam Vellner, founder: "honestly haven't had a real weekend since March"
> 2. Petra Onstad, studio owner: "I fall asleep with my laptop open, send help"
> 3. Dario Kemp, CEO: "5 hours of sleep is a good night for me lately"
> 4. Mira Solheim, consultant: "my brain does not have an off switch anymore"

> **You:** screen
> **It:** 4 in, 1 survived. Dropped: Sam (already your client), Petra (on your
> do-not-contact list), Dario (you messaged him 5 days ago). Next: draft.

> **You:** draft
> **It:** 1. Mira Solheim, LinkedIn
> Draft: "booked through December and no off switch, that's a wild combo.
> how are you actually holding up?"
> Reply with the numbers you approve.

> **You:** 1
> **It:** Approved. Copy it, send it from your LinkedIn, and I have logged her
> so you can never accidentally message her twice.

That is the whole system: evidence in, protected people out, your voice,
your finger on send. Ten minutes a day keeps the pipeline full.
