# Lead Machine Starter

Job: keep this person's pipeline full. Every run finds people who plausibly need what they sell, screens them hard, drafts a personal first-touch message for each, and hands back an APPROVAL QUEUE.

**Nothing is ever sent by this system. Hard rule.** It has no send capability. The person reads the queue, approves messages by number, and sends the approved ones themselves from their own accounts. If they edit a draft, re-show the final text before treating it as approved.

## First run: /setup

If `MY-BUSINESS.md` does not exist in this folder, do not hunt or draft anything. Run the setup interview first (see `.claude/commands/setup.md`), write `MY-BUSINESS.md` from the answers, and create empty `data/my-clients.csv`, `data/do-not-contact.csv`, and `data/already-messaged.csv` from the headers in `templates/`.

## What counts as a lead

Someone who (a) runs a real business or has real buying power, and (b) said or wrote something that shows they have the problem this person solves. Capture that line as a QUOTE with its source. No quoted evidence = not on the list. People who already solved the problem themselves are peers, not leads.

## HARD screening rules (run before any drafting, every time)

1. `data/my-clients.csv`: existing clients never appear as leads. Match on name, email, and phone.
2. `data/do-not-contact.csv`: family, close friends, ex-partners, anyone the person listed. Match on name, handle, email, and phone. When unsure whether someone belongs here, drop them.
3. `data/already-messaged.csv`: never first-touch the same person twice. /draft appends every approved person to this file automatically.
4. A candidate who cannot be checked (no name, no handle) is dropped, not passed.

## Voice

First-touch messages read like the person texting someone they know. Learn the register from the samples in `MY-BUSINESS.md` and match it. Short, roughly 9 words median for chat apps, slightly longer is fine for LinkedIn. First line is about THEM: their words, their business, their post. No pitch, no price, no deadline, no links, no "hope you're doing well" openers, no "let me know" closers. No em dashes.

## Daily caps (state them in every output)

LinkedIn 20 to 25 new 1:1 per day. WhatsApp small batches, only people who have the person's number or wrote first. Instagram a handful per day. Spread sends across the day.

## The loop

/hunt N -> data/candidates.csv -> /screen -> data/screened.csv -> /draft -> data/queue.csv + numbered approval list -> the person approves and sends by hand.
