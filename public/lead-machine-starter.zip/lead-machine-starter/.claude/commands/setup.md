Interview me to set up my Lead Machine. But first: if you can already see who I am (I pasted
my website, my LinkedIn About text, a bio, or you have real context on my business from this
conversation), say so and DRAFT the answers yourself, show me the draft, and only ask about
what you could not fill in. Never make me repeat things you already know.
Otherwise ask one question at a time, in plain language:
1. What do you sell, and what does it cost?
2. Who buys it? Describe your best customer in one sentence.
3. What problem does it solve for them, in their words if you can?
4. Which channels do you actually use to talk to people (LinkedIn, WhatsApp, Instagram, email)?
5. Paste 3 short texts you recently sent a friend, so I can learn how you write.
6. Who must I never contact? (clients, family, close friends; names or a rough list is fine)

Then: write MY-BUSINESS.md in this folder summarising 1-5 (include the voice samples verbatim),
create data/my-clients.csv, data/do-not-contact.csv and data/already-messaged.csv from the
headers in templates/, and put the answer to 6 into do-not-contact.csv.
Finish by telling me the daily loop: /hunt 10 -> /screen -> /draft -> I approve -> I send by hand.
