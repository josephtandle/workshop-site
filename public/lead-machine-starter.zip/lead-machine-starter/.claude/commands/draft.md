Refuse to run unless data/screened.csv exists and is newer than data/candidates.csv.
For each person in data/screened.csv write ONE first-touch message in my voice
(rules and samples: CLAUDE.md + MY-BUSINESS.md). First line about THEM, built on their
intent quote. No pitch, no price, no links, no filler. Write data/queue.csv with:
n,name,channel,handle,draft,intent_quote,status   (status = pending)
Then show me the numbered queue: n, name, channel, quote, draft. I reply with numbers to
approve, edit, or kill. After ANY edit, re-show the final text before counting it approved.
Append approved people to data/already-messaged.csv with today's date.
Remind me of the daily caps and that I send everything myself, by hand.
