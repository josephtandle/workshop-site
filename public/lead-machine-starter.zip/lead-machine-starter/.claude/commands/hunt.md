Find $ARGUMENTS people I have never contacted who plausibly need what I sell (see MY-BUSINESS.md).
Sources, in order of value:
1. data/Connections.csv (my LinkedIn export) - people whose title/company fits my best customer.
2. Anything I paste or point you to: comments on my posts, replies in my inbox, community threads.
3. People I mention from memory - ask me for the evidence line.
For each person capture a QUOTED line that shows they have the problem I solve, and where it is from.
No quote = not on the list. Write data/candidates.csv with:
name,channel,handle,email,business,intent_quote,quote_source,notes
Do not screen or draft yet. End by telling me the count and the daily caps.
