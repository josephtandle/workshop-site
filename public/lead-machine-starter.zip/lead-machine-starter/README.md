# Lead Machine Starter

A little system that goes through the people you already have some link to, your LinkedIn connections, people who commented on your posts, replies in your inbox, or names you give it, and finds the ones who have shown they have the problem you solve. It writes a short personal first message for each, in your voice. You approve every message, then you send it yourself. It never sends anything, and it never goes hunting strangers on the open web. You feed it your own world, it finds the warm people already in it.

From Joe Che's AI class. This is the starter version of the system that runs his own pipeline.

## The easy way (any AI, no install, 2 minutes)

1. Open **BROWSER-VERSION.txt** in this folder.
2. Copy the prompt inside it.
3. Open your AI in a browser (ChatGPT, Claude, Grok, Gemini, any of them), start a new chat, paste it, and send.

It asks you a few questions about your business, then you are running. Come back to the same chat every day.

**To give it people to work with**, the best fuel is your LinkedIn connections file: LinkedIn, Settings, Data privacy, Get a copy of your data, pick "Connections", download. LinkedIn emails you a `Connections.csv`. When the chat says to hunt, paste those rows in, or just paste people who commented on your posts. Any list of people works.

## Use (10 minutes a day)

- **hunt 10** it looks through the people you gave it and finds 10 worth talking to, each with proof they have the problem you solve.
- **screen** it removes clients, family, close friends, and anyone you already messaged.
- **draft** it writes one short personal message per person and shows you a numbered list.

You read the list. You say which numbers are good. Then YOU copy each approved message and send it yourself from your own LinkedIn or WhatsApp. Sending by hand is the point: no banned accounts, no accidental spam, and you stay the human in the conversation.

## The three rules that make this work

1. Nobody goes on the list without a quoted line showing they have the problem you solve. Interest is not evidence.
2. Never message clients, family, or close friends. The `do-not-contact.csv` file is yours to fill; when unsure, the system drops the person.
3. Never send a message you have not read and approved word for word.

## Daily limits (respect them or your accounts die)

LinkedIn: at most 20 to 25 new people per day, spread out. WhatsApp: small batches, only people who already have your number or messaged you first. Instagram: a handful per day.

## Optional: the folder version (advanced, only if you use a terminal tool)

The same kit also runs as a folder inside Claude Code, Codex, or Gemini CLI, where it keeps its own memory of everyone you have messaged across days, so you never repeat yourself.

1. Install one of: Claude Code (https://claude.com/claude-code), Codex, or Gemini CLI.
2. Open this folder in that tool.
3. Say **"set me up"** and answer its questions. Drop your `Connections.csv` into the `data/` folder.
4. Then each day: **hunt 10**, **screen**, **draft**. On Claude Code these are `/hunt`, `/screen`, `/draft`; on the others just say them in plain words.

If a terminal is not your thing, ignore this section. The browser way above does the same job.
