# Lead Machine Starter

A little system that finds people who might buy from you, checks them against the people you must never pitch, and writes a short personal first message for each one. You approve every message before anything is sent. It never sends anything itself.

From Joe Che's AI class. This is the starter version of the system that runs his own pipeline.

## Set up (once, about 15 minutes)

1. Install Claude Code: https://claude.com/claude-code (or use Codex from ChatGPT, or Gemini CLI; this kit works with all of them)
2. Put this folder anywhere on your computer (Desktop is fine).
3. Open a terminal in this folder and type `claude`.
4. Say: **"set me up"** and answer its questions (what you sell, what it costs, who buys it, and paste 3 texts you sent a friend so it learns how you write).
5. Download your LinkedIn connections: LinkedIn -> Settings -> Data privacy -> Get a copy of your data -> Connections. Drop the `Connections.csv` file into the `data/` folder here.

That's it.

## Use (10 minutes a day)

```
/hunt 10     it finds 10 people worth talking to, with proof they have the problem you solve
/screen      it removes clients, family, close friends, and anyone you already messaged
/draft       it writes one short personal message per person and shows you a numbered list
```

On Codex or Gemini there are no slash commands; just say "hunt 10", "screen", "draft" in plain words and it will follow the same steps.

You read the list. You say which numbers are good. Then YOU copy each approved message and send it yourself from your own LinkedIn or WhatsApp. Sending by hand is the point: no banned accounts, no accidental spam, and you stay the human in the conversation.

## The three rules that make this work

1. Nobody goes on the list without a quoted line showing they have the problem you solve. Interest is not evidence.
2. Never message clients, family, or close friends. The `do-not-contact.csv` file is yours to fill; when unsure, the system drops the person.
3. Never send a message you have not read and approved word for word.

## Daily limits (respect them or your accounts die)

LinkedIn: at most 20 to 25 new people per day, spread out. WhatsApp: small batches, only people who already have your number or messaged you first. Instagram: a handful per day.
