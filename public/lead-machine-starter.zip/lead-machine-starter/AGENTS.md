# Lead Machine Starter (Codex / other AI agents)

If you are reading this file, you are probably Codex or another AI coding agent. The full spec is in CLAUDE.md in this folder; every rule in it applies to you exactly as written, especially: nothing is ever sent by this system, and screening runs before drafting, every time.

This folder's commands live in `.claude/commands/` as plain instruction files. There are no slash commands here; when the person says any of these, read the matching file and follow it:

- "set me up" -> `.claude/commands/setup.md`
- "hunt 10" (any number) -> `.claude/commands/hunt.md`
- "screen" -> `.claude/commands/screen.md`
- "draft" -> `.claude/commands/draft.md`
