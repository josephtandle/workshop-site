const fs = require('fs');
const path = require('path');
const os = require('os');

const HOME = os.homedir();

const DEFAULT_THRESHOLD_MB = 100;
const MAX_DEPTH = 5;
const MAX_RESULTS = 500;

const SCAN_DIRS = [
  path.join(HOME, 'Documents'),
  path.join(HOME, 'Desktop'),
  path.join(HOME, 'Downloads'),
  path.join(HOME, 'Movies'),
  path.join(HOME, 'Library', 'Application Support'),
  path.join(HOME, 'Library', 'Developer'),
];

function walkDir(dirPath, thresholdBytes, depth, results) {
  if (depth > MAX_DEPTH || results.length >= MAX_RESULTS) {
    return;
  }

  let entries;
  try {
    entries = fs.readdirSync(dirPath, { withFileTypes: true });
  } catch {
    return;
  }

  for (const entry of entries) {
    if (results.length >= MAX_RESULTS) {
      return;
    }

    if (entry.name.startsWith('.')) {
      continue;
    }

    const fullPath = path.join(dirPath, entry.name);

    if (entry.isDirectory()) {
      walkDir(fullPath, thresholdBytes, depth + 1, results);
    } else if (entry.isFile()) {
      let stat;
      try {
        stat = fs.statSync(fullPath);
      } catch {
        continue;
      }

      if (stat.size >= thresholdBytes) {
        results.push({
          path: fullPath,
          size_mb: Math.round((stat.size / (1024 * 1024)) * 100) / 100,
          modified: stat.mtime.toISOString(),
        });
      }
    }
  }
}

async function scanLargeFiles(config = {}) {
  const thresholdMb = config.largeFileThresholdMb || DEFAULT_THRESHOLD_MB;
  const thresholdBytes = thresholdMb * 1024 * 1024;
  const results = [];

  for (const dir of SCAN_DIRS) {
    if (results.length >= MAX_RESULTS) {
      break;
    }

    try {
      fs.accessSync(dir, fs.constants.R_OK);
    } catch {
      continue;
    }

    walkDir(dir, thresholdBytes, 0, results);
  }

  results.sort((a, b) => b.size_mb - a.size_mb);

  return results.slice(0, MAX_RESULTS);
}

module.exports = { scanLargeFiles };

if (require.main === module) {
  const args = process.argv.slice(2);
  let thresholdMb = DEFAULT_THRESHOLD_MB;

  const thresholdIdx = args.indexOf('--threshold-mb');
  if (thresholdIdx !== -1 && args[thresholdIdx + 1]) {
    const parsed = Number(args[thresholdIdx + 1]);
    if (!isNaN(parsed) && parsed > 0) {
      thresholdMb = parsed;
    }
  }

  scanLargeFiles({ largeFileThresholdMb: thresholdMb })
    .then((files) => {
      const totalSize = files.reduce((sum, f) => sum + f.size_mb, 0);
      const output = {
        success: true,
        files,
        totalSize: Math.round(totalSize * 100) / 100,
        scannedAt: new Date().toISOString(),
      };
      process.stdout.write(JSON.stringify(output, null, 2));
    })
    .catch((err) => {
      process.stderr.write(err.message);
      process.exit(1);
    });
}
