#!/usr/bin/env node

const fs = require("fs");
const path = require("path");
const os = require("os");
const { execFileSync, execSync } = require("child_process");
const { writeStatus } = require("./status");
const { cleanDevArtifacts } = require("./dev-artifacts");
const { cleanBrowserCaches } = require("./browser-cache");
const { cleanOldIOSBackups } = require("./system-tuneup");

const HOME = os.homedir();
const DATA_DIR = process.env.MC_DATA_DIR || path.join(os.homedir(), ".maccleaner", "data");
const CONFIG_FILE = process.env.MC_CONFIG_FILE || path.join(os.homedir(), ".maccleaner", "config.json");
const LAST_RUN_FILE = path.join(DATA_DIR, "last-run.json");
const PREVIEW_FILE = path.join(DATA_DIR, "preview.json");
const HISTORY_FILE = path.join(DATA_DIR, "history.json");
const LIFETIME_FILE = path.join(DATA_DIR, "lifetime-stats.json");

const DRY_RUN = process.argv.includes("--dry-run");
const CONFIRM_CLEAN = process.argv.includes("--confirm-clean");

function loadConfig() {
  try {
    return JSON.parse(fs.readFileSync(CONFIG_FILE, "utf-8"));
  } catch {
    return {
      cacheMaxAgeDays: 0,
      logMaxAgeDays: 30,
      trashMaxAgeDays: 30,
      npmCacheThresholdMb: 500,
      brewPruneDays: 30,
      nextBuildMaxAgeDays: 7,
      xcodeMaxAgeDays: 30,
      };
  }
}

function getDirSizeBytes(dirPath) {
  try {
    const result = execSync(`du -sk "${dirPath}" 2>/dev/null`, { encoding: 'utf-8', timeout: 30000 });
    const kb = parseInt(result.split('\t')[0], 10);
    return isNaN(kb) ? 0 : kb * 1024;
  } catch {
    return 0;
  }
}

function getDiskFreeBytes() {
  try {
    const df = execSync('df -k /System/Volumes/Data', { encoding: 'utf-8' });
    const parts = df.split('\n')[1].trim().split(/\s+/);
    return parseInt(parts[3], 10) * 1024;
  } catch { return 0; }
}

// Allowed top-level directories for deletion -- never delete outside these paths
const ALLOWED_PREFIXES = [
  path.join(HOME, "Library", "Caches"),
  path.join(HOME, "Library", "Logs"),
  path.join(HOME, "Library", "Developer", "Xcode", "DerivedData"),
  path.join(HOME, ".Trash"),
  path.join(HOME, ".npm"),
  path.join(HOME, "Downloads"),
];

function isAllowedPath(targetPath) {
  const normalized = path.resolve(targetPath);
  // Also allow top-level home-dir folders that start with U+2215 (unicode orphan tmp)
  if (path.dirname(normalized) === HOME && path.basename(normalized).startsWith("\u2215")) {
    return true;
  }
  return ALLOWED_PREFIXES.some(
    (prefix) => normalized === prefix || normalized.startsWith(prefix + path.sep)
  );
}

function isSafeTarget(targetPath) {
  // Reject symlinks to prevent traversal into unexpected locations
  try {
    return !fs.lstatSync(targetPath).isSymbolicLink();
  } catch {
    return false;
  }
}

function removeDirRecursive(dirPath) {
  if (DRY_RUN) return true;
  if (!isAllowedPath(dirPath) || !isSafeTarget(dirPath)) return false;
  try {
    fs.rmSync(dirPath, { recursive: true, force: true });
    return true;
  } catch {
    return false;
  }
}

function removeFile(filePath) {
  if (DRY_RUN) return true;
  if (!isAllowedPath(filePath) || !isSafeTarget(filePath)) return false;
  try {
    fs.unlinkSync(filePath);
    return true;
  } catch {
    return false;
  }
}

function isOlderThanDays(mtimeMs, days) {
  const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
  return mtimeMs < cutoff;
}

// ── Cleanup Tasks ──────────────────────────────────────────────────

function cleanLibraryCaches(config, items, errors) {
  const cachesDir = path.join(HOME, "Library", "Caches");
  const maxAgeDays = config.cacheMaxAgeDays || 0;
  try {
    const entries = fs.readdirSync(cachesDir, { withFileTypes: true });
    for (const entry of entries) {
      if (!entry.isDirectory()) continue;
      const fullPath = path.join(cachesDir, entry.name);
      try {
        // When cacheMaxAgeDays > 0, only delete cache dirs older than that many days
        if (maxAgeDays > 0) {
          const stat = fs.statSync(fullPath);
          if (!isOlderThanDays(stat.mtimeMs, maxAgeDays)) continue;
        }
        const sizeMb = getDirSizeBytes(fullPath) / (1024 * 1024);
        if (sizeMb < 0.01) continue; // skip tiny dirs
        if (removeDirRecursive(fullPath)) {
          items.push({ path: fullPath, size_mb: Math.round(sizeMb * 100) / 100, reason: maxAgeDays > 0 ? `Library/Caches older than ${maxAgeDays} days` : "Library/Caches cleanup" });
        }
      } catch (err) {
        errors.push(`Cache dir ${entry.name}: ${err.message}`);
      }
    }
  } catch (err) {
    errors.push(`Library/Caches: ${err.message}`);
  }
}

// cleanNextBuild removed — not applicable in standalone mode

function cleanOrphanedTmpFolders(items, errors) {
  // Some macOS apps (notably older Electron-based apps) create temporary directories
  // using U+2215 DIVISION SLASH (∕) as a path separator rather than the standard
  // forward slash. This produces orphaned folders named like "∕tmp∕app-name" directly
  // in the user's home directory. These are safe to delete -- they are never accessed
  // by any running process because the path with U+2215 is not a valid POSIX path.
  const UNICODE_SLASH = "\u2215"; // U+2215 DIVISION SLASH (∕) -- visually similar to / but distinct
  try {
    const entries = fs.readdirSync(HOME, { withFileTypes: true });
    for (const entry of entries) {
      if (!entry.isDirectory()) continue;
      if (entry.name.startsWith(UNICODE_SLASH + "tmp" + UNICODE_SLASH)) {
        const fullPath = path.join(HOME, entry.name);
        try {
          const sizeMb = getDirSizeBytes(fullPath) / (1024 * 1024);
          if (removeDirRecursive(fullPath)) {
            items.push({ path: fullPath, size_mb: Math.round(sizeMb * 100) / 100, reason: "Orphaned tmp-style folder" });
          }
        } catch (err) {
          errors.push(`Tmp folder ${entry.name}: ${err.message}`);
        }
      }
    }
  } catch (err) {
    errors.push(`Home dir scan: ${err.message}`);
  }
}

function cleanChromeOrphans(config, items, errors) {
  const scriptPath = path.join(__dirname, "chrome-orphans.js");
  const args = [scriptPath];
  if (DRY_RUN) args.push("--dry-run");

  try {
    const raw = execFileSync(process.execPath, args, {
      encoding: "utf-8",
      timeout: 15000,
      maxBuffer: 1024 * 1024,
      env: {
        ...process.env,
        MC_CONFIG_FILE: CONFIG_FILE,
        MC_CHROME_ORPHAN_PORTS: JSON.stringify(config.chromeOrphanPorts || []),
      },
    }).trim();
    if (!raw) return;

    const result = JSON.parse(raw);
    if (Array.isArray(result.items)) {
      items.push(...result.items);
    }
    if (Array.isArray(result.errors)) {
      errors.push(...result.errors);
    }
  } catch (err) {
    errors.push(`cleanChromeOrphans: ${err.message}`);
  }
}

function cleanOldLogs(config, items, errors) {
  const logsDir = path.join(HOME, "Library", "Logs");
  const maxAgeDays = config.logMaxAgeDays || 30;
  try {
    cleanOldFilesRecursive(logsDir, maxAgeDays, "Old log file", items, errors);
  } catch (err) {
    errors.push(`Library/Logs: ${err.message}`);
  }
}

function cleanOldFilesRecursive(dirPath, maxAgeDays, reason, items, errors) {
  try {
    const entries = fs.readdirSync(dirPath, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(dirPath, entry.name);
      try {
        if (entry.isDirectory()) {
          cleanOldFilesRecursive(fullPath, maxAgeDays, reason, items, errors);
          // Remove empty dirs
          if (!DRY_RUN) {
            try {
              const remaining = fs.readdirSync(fullPath);
              if (remaining.length === 0) {
                fs.rmdirSync(fullPath);
              }
            } catch { /* ignore */ }
          }
        } else {
          const stat = fs.statSync(fullPath);
          if (isOlderThanDays(stat.mtimeMs, maxAgeDays)) {
            const sizeMb = stat.size / (1024 * 1024);
            if (removeFile(fullPath)) {
              items.push({ path: fullPath, size_mb: Math.round(sizeMb * 100) / 100, reason });
            }
          }
        }
      } catch (err) {
        errors.push(`${fullPath}: ${err.message}`);
      }
    }
  } catch {
    // skip inaccessible dirs
  }
}

function cleanOldTrash(config, items, errors) {
  const trashDir = path.join(HOME, ".Trash");
  const maxAgeDays = config.trashMaxAgeDays || 30;
  let entries;
  try {
    entries = fs.readdirSync(trashDir, { withFileTypes: true });
  } catch (err) {
    // EPERM is expected on macOS 15+ for launchd processes without Full Disk Access.
    // Skip trash cleanup silently rather than surfacing a misleading error.
    if (err.code !== 'EPERM') {
      errors.push(`Trash dir: ${err.message}`);
    }
    return;
  }
  for (const entry of entries) {
    const fullPath = path.join(trashDir, entry.name);
    try {
      const stat = fs.statSync(fullPath);
      if (isOlderThanDays(stat.mtimeMs, maxAgeDays)) {
        const sizeMb = (entry.isDirectory() ? getDirSizeBytes(fullPath) : stat.size) / (1024 * 1024);
        const removed = entry.isDirectory() ? removeDirRecursive(fullPath) : removeFile(fullPath);
        if (removed) {
          items.push({ path: fullPath, size_mb: Math.round(sizeMb * 100) / 100, reason: `Trash item older than ${maxAgeDays} days` });
        }
      }
    } catch (err) {
      if (err.code !== 'EPERM') {
        errors.push(`Trash ${entry.name}: ${err.message}`);
      }
    }
  }
}

function cleanNpmCache(config, items, errors) {
  const npmCacheDir = path.join(HOME, ".npm", "_cacache");
  try {
    const sizeMb = getDirSizeBytes(npmCacheDir) / (1024 * 1024);
    const threshold = config.npmCacheThresholdMb || 500;
    if (sizeMb > threshold) {
      if (DRY_RUN) {
        items.push({ path: npmCacheDir, size_mb: Math.round(sizeMb * 100) / 100, reason: `npm cache exceeded ${threshold}MB threshold` });
      } else {
        try {
          execSync("npm cache clean --force", { stdio: "pipe", timeout: 60000 });
          items.push({ path: npmCacheDir, size_mb: Math.round(sizeMb * 100) / 100, reason: `npm cache exceeded ${threshold}MB threshold` });
        } catch (err) {
          errors.push(`npm cache clean: ${err.message}`);
        }
      }
    }
  } catch {
    // npm cache dir doesn't exist
  }
}

function cleanBrewCache(config, items, errors) {
  try {
    execSync("which brew", { stdio: "pipe" });
  } catch {
    return; // brew not installed
  }

  try {
    // Get cache size before cleanup
    let sizeBefore = 0;
    try {
      const brewCacheDir = execSync("brew --cache", { stdio: "pipe", encoding: "utf-8" }).trim();
      sizeBefore = getDirSizeBytes(brewCacheDir) / (1024 * 1024);
    } catch { /* ignore */ }

    if (DRY_RUN) {
      // In dry-run, report the full cache size as what would be freed
      if (sizeBefore > 0.01) {
        items.push({ path: "brew cache", size_mb: Math.round(sizeBefore * 100) / 100, reason: `brew cleanup --prune=${config.brewPruneDays || 30} (estimated)` });
      }
      return;
    }

    // Validate brewPruneDays is a safe integer (1-365) before shell interpolation
    const pruneDays = Math.max(1, Math.min(365, parseInt(String(config.brewPruneDays), 10) || 30));
    execSync(`brew cleanup --prune=${pruneDays}`, { stdio: "pipe", timeout: 120000 });

    let sizeAfter = 0;
    try {
      const brewCacheDir = execSync("brew --cache", { stdio: "pipe", encoding: "utf-8" }).trim();
      sizeAfter = getDirSizeBytes(brewCacheDir) / (1024 * 1024);
    } catch { /* ignore */ }

    const freedMb = Math.max(0, sizeBefore - sizeAfter);
    if (freedMb > 0.01) {
      items.push({ path: "brew cache", size_mb: Math.round(freedMb * 100) / 100, reason: `brew cleanup --prune=${pruneDays}` });
    }
  } catch (err) {
    errors.push(`brew cleanup: ${err.message}`);
  }
}

function cleanXcodeDerivedData(config, items, errors) {
  const derivedDataDir = path.join(HOME, 'Library', 'Developer', 'Xcode', 'DerivedData');
  const maxAgeDays = config.xcodeMaxAgeDays || 30;
  try {
    if (!fs.existsSync(derivedDataDir)) return;
    const entries = fs.readdirSync(derivedDataDir, { withFileTypes: true });
    for (const entry of entries) {
      if (!entry.isDirectory()) continue;
      const fullPath = path.join(derivedDataDir, entry.name);
      try {
        const stat = fs.statSync(fullPath);
        if (isOlderThanDays(stat.mtimeMs, maxAgeDays)) {
          const sizeMb = getDirSizeBytes(fullPath) / (1024 * 1024);
          if (removeDirRecursive(fullPath)) {
            items.push({ path: fullPath, size_mb: Math.round(sizeMb * 100) / 100, reason: `Xcode DerivedData older than ${maxAgeDays} days` });
          }
        }
      } catch (err) {
        errors.push(`Xcode DerivedData ${entry.name}: ${err.message}`);
      }
    }
  } catch (err) {
    errors.push(`Xcode DerivedData: ${err.message}`);
  }
}

// ── History ─────────────────────────────────────────────────────────

const MAX_HISTORY_ENTRIES = 10;

function appendHistory(report) {
  let history = [];
  try {
    history = JSON.parse(fs.readFileSync(HISTORY_FILE, "utf-8"));
  } catch {
    // No history yet
  }
  history.unshift(report);
  if (history.length > MAX_HISTORY_ENTRIES) {
    history = history.slice(0, MAX_HISTORY_ENTRIES);
  }
  fs.writeFileSync(HISTORY_FILE, JSON.stringify(history, null, 2));
}

// ── Lifetime Stats ──────────────────────────────────────────────────

function updateLifetimeStats(report) {
  let stats = { totalBytesFreed: 0, totalRuns: 0, firstRun: null, lastRun: null };
  try {
    stats = JSON.parse(fs.readFileSync(LIFETIME_FILE, "utf-8"));
  } catch {
    // No lifetime file yet — start fresh
  }
  stats.totalBytesFreed = (stats.totalBytesFreed || 0) + report.bytes_freed;
  stats.totalRuns = (stats.totalRuns || 0) + 1;
  if (!stats.firstRun) stats.firstRun = report.timestamp;
  stats.lastRun = report.timestamp;
  fs.writeFileSync(LIFETIME_FILE, JSON.stringify(stats, null, 2));
}

// ── Telegram ────────────────────────────────────────────────────────

function sendTelegramNotification(report) {
  if (process.env.MACCLEANER_ENABLE_TELEGRAM !== "1") return;
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;
  if (!token || !chatId) return; // Telegram not configured — skip silently

  const totalGb = (report.bytes_freed / (1024 ** 3)).toFixed(2);

  let diskLine = '';
  try {
    const df = execSync('df -k /System/Volumes/Data', { encoding: 'utf-8' });
    const parts = df.split('\n')[1].trim().split(/\s+/);
    const freeGb = (parseInt(parts[3]) * 1024 / (1024 ** 3)).toFixed(1);
    const totalGbDisk = (parseInt(parts[1]) * 1024 / (1024 ** 3)).toFixed(0);
    diskLine = `\n\u{1F4BE} <b>${freeGb} GB free</b> of ${totalGbDisk} GB`;
  } catch {}

  const text = `\u{1F9F9} <b>MacCleaner ran</b>\n\nFreed <b>${totalGb} GB</b> across ${report.items_cleaned.length} items in ${(report.duration_ms / 1000).toFixed(1)}s${diskLine}${report.errors.length > 0 ? `\n\u26A0\uFE0F ${report.errors.length} errors` : ''}`;

  const body = JSON.stringify({ chat_id: chatId, text, parse_mode: 'HTML' });
  const https = require('https');
  const req = https.request(`https://api.telegram.org/bot${token}/sendMessage`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) }
  }, (res) => { res.resume(); });
  req.on('error', (e) => console.log('[mac-cleaner] Telegram error:', e.message));
  req.write(body);
  req.end();
}

// ── Main ───────────────────────────────────────────────────────────

function main() {
  const startMs = Date.now();
  const config = loadConfig();
  const items = [];
  const errors = [];
  const previewOnly = DRY_RUN || !CONFIRM_CLEAN;

  console.log(`[mac-cleaner] Starting disk cleanup${previewOnly ? " (DRY RUN)" : ""}...`);
  if (!CONFIRM_CLEAN) {
    console.log("[mac-cleaner] Confirmation required for destructive cleanup. Showing preview only.");
  }

  cleanLibraryCaches(config, items, errors);
  cleanOrphanedTmpFolders(items, errors);
  cleanOldLogs(config, items, errors);
  cleanOldTrash(config, items, errors);
  cleanNpmCache(config, items, errors);
  cleanBrewCache(config, items, errors);
  cleanXcodeDerivedData(config, items, errors);
  cleanBrowserCaches(config, items, errors, previewOnly);
  cleanDevArtifacts(config, items, errors, previewOnly);
  cleanOldIOSBackups(config, items, errors, previewOnly);
  cleanChromeOrphans(config, items, errors);

  const durationMs = Date.now() - startMs;
  const totalMb = items.reduce((sum, i) => sum + i.size_mb, 0);
  const totalBytes = Math.round(totalMb * 1024 * 1024);
  const diskFreeBytes = getDiskFreeBytes();

  const report = {
    timestamp: new Date().toISOString(),
    bytes_freed: totalBytes,
    items_cleaned: items,
    errors,
    duration_ms: durationMs,
    disk_free_bytes: diskFreeBytes,
  };

  // Write report
  fs.mkdirSync(DATA_DIR, { recursive: true });

  if (previewOnly) {
    fs.writeFileSync(PREVIEW_FILE, JSON.stringify(report, null, 2));
    const totalGb = (totalMb / 1024).toFixed(2);
    console.log(`[mac-cleaner] DRY RUN — would free ${totalGb} GB across ${items.length} items`);
    console.log(`[mac-cleaner] Preview written to ${PREVIEW_FILE}`);
    return;
  }

  fs.writeFileSync(LAST_RUN_FILE, JSON.stringify(report, null, 2));

  // Append to rolling history (max 10 entries)
  appendHistory(report);

  // Accumulate lifetime total
  updateLifetimeStats(report);

  // Write status
  const totalGb = (totalMb / 1024).toFixed(2);
  const summary = `Freed ${totalGb} GB across ${items.length} items in ${(durationMs / 1000).toFixed(1)}s`;
  writeStatus(errors.length > 0 ? "error" : "ok", summary);

  console.log(`[mac-cleaner] ${summary}`);
  if (errors.length > 0) {
    console.log(`[mac-cleaner] ${errors.length} errors encountered`);
  }
  console.log(`[mac-cleaner] Report written to ${LAST_RUN_FILE}`);

  // Send Telegram notification
  sendTelegramNotification(report);
}

main();
