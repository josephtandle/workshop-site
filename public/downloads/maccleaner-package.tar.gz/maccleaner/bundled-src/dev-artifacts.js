/**
 * Dev Artifacts Cleaner — standalone plugin for mac-cleaner
 *
 * Scans common project directories for stale developer artifact folders
 * (node_modules, venvs, Rust targets, Gradle cache, __pycache__) and
 * removes them when they exceed the configured age threshold.
 *
 * Usage:
 *   const { cleanDevArtifacts } = require("./dev-artifacts");
 *   cleanDevArtifacts(config, items, errors, dryRun);
 */

const fs = require("fs");
const path = require("path");
const os = require("os");
const { execSync } = require("child_process");

const HOME = os.homedir();

const SCAN_ROOTS = [
  path.join(HOME, "Documents"),
  path.join(HOME, "Desktop"),
  path.join(HOME, "code"),
  path.join(HOME, "projects"),
  path.join(HOME, "src"),
  path.join(HOME, "workspace"),
  path.join(HOME, "Developer"),
];

const NODE_MODULES = "node_modules";
const PYTHON_VENVS = [".venv", "venv", "env"];
const PYCACHE = "__pycache__";
const RUST_TARGET = "target";
const GRADLE_DIR = ".gradle";

const PYCACHE_MIN_BYTES = 10 * 1024 * 1024; // 10 MB

function getDirSizeBytes(dirPath) {
  try {
    const result = execSync(`du -sk "${dirPath}" 2>/dev/null`, {
      encoding: "utf-8",
      timeout: 30000,
    });
    const kb = parseInt(result.split("\t")[0], 10);
    return isNaN(kb) ? 0 : kb * 1024;
  } catch {
    return 0;
  }
}

function isOlderThanDays(mtimeMs, days) {
  const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
  return mtimeMs < cutoff;
}

function safeStat(p) {
  try {
    return fs.statSync(p);
  } catch {
    return null;
  }
}

function safeReaddir(p) {
  try {
    return fs.readdirSync(p, { withFileTypes: true });
  } catch {
    return [];
  }
}

function isProtectedPath(p) {
  return p.includes(".myos");
}

/**
 * Walk directories up to `maxDepth` levels below `root`, calling `visitor`
 * for every directory entry encountered.
 */
function walkDirs(root, maxDepth, visitor) {
  if (maxDepth < 0) return;
  const entries = safeReaddir(root);
  for (const entry of entries) {
    if (!entry.isDirectory()) continue;
    const fullPath = path.join(root, entry.name);
    if (isProtectedPath(fullPath)) continue;
    visitor(fullPath, entry.name, root);
    if (maxDepth > 0) {
      walkDirs(fullPath, maxDepth - 1, visitor);
    }
  }
}

function removeDirRecursive(dirPath, dryRun) {
  if (dryRun) return true;
  try {
    fs.rmSync(dirPath, { recursive: true, force: true });
    return true;
  } catch {
    return false;
  }
}

/**
 * Returns true if `child` is a direct or nested child of one of the
 * SCAN_ROOTS (never the root itself).
 */
function isChildOfScanRoot(childPath) {
  const resolved = path.resolve(childPath);
  return SCAN_ROOTS.some((root) => {
    const resolvedRoot = path.resolve(root);
    return (
      resolved !== resolvedRoot &&
      resolved.startsWith(resolvedRoot + path.sep)
    );
  });
}

function processArtifact(artifactPath, reason, maxAgeDays, items, errors, dryRun) {
  if (!isChildOfScanRoot(artifactPath)) return;
  if (isProtectedPath(artifactPath)) return;

  const stat = safeStat(artifactPath);
  if (!stat) return;
  if (!isOlderThanDays(stat.mtimeMs, maxAgeDays)) return;

  const sizeBytes = getDirSizeBytes(artifactPath);
  const sizeMb = Math.round((sizeBytes / (1024 * 1024)) * 100) / 100;

  if (removeDirRecursive(artifactPath, dryRun)) {
    items.push({
      path: artifactPath,
      size_mb: sizeMb,
      reason: `${reason} older than ${maxAgeDays} days`,
    });
  } else {
    errors.push(`Failed to remove ${artifactPath}`);
  }
}

/**
 * Main entry point — scans for and removes stale dev artifacts.
 *
 * @param {object} config - mac-cleaner config (expects devArtifactsMaxAgeDays)
 * @param {Array}  items  - accumulator for cleaned items
 * @param {Array}  errors - accumulator for errors
 * @param {boolean} dryRun - if true, report but do not delete
 */
function cleanDevArtifacts(config, items, errors, dryRun) {
  const maxAgeDays = config.devArtifactsMaxAgeDays || 30;

  // -- node_modules, Python venvs, Rust targets, __pycache__ --
  for (const root of SCAN_ROOTS) {
    if (!safeStat(root)) continue;

    walkDirs(root, 3, (fullPath, name, parentDir) => {
      // node_modules
      if (name === NODE_MODULES) {
        processArtifact(fullPath, "Dev artifact: node_modules", maxAgeDays, items, errors, dryRun);
        return;
      }

      // Python virtual environments
      if (PYTHON_VENVS.includes(name)) {
        // Verify it looks like a venv (has pyvenv.cfg or bin/activate)
        const hasCfg =
          safeStat(path.join(fullPath, "pyvenv.cfg")) ||
          safeStat(path.join(fullPath, "bin", "activate"));
        if (hasCfg) {
          processArtifact(fullPath, `Dev artifact: Python venv (${name})`, maxAgeDays, items, errors, dryRun);
        }
        return;
      }

      // Rust target/ with Cargo.toml sibling
      if (name === RUST_TARGET) {
        const cargoToml = path.join(parentDir, "Cargo.toml");
        if (safeStat(cargoToml)) {
          processArtifact(fullPath, "Dev artifact: Rust target", maxAgeDays, items, errors, dryRun);
        }
        return;
      }

      // __pycache__ (only large ones)
      if (name === PYCACHE) {
        const sizeBytes = getDirSizeBytes(fullPath);
        if (sizeBytes >= PYCACHE_MIN_BYTES) {
          processArtifact(fullPath, "Dev artifact: __pycache__", maxAgeDays, items, errors, dryRun);
        }
        return;
      }
    });
  }

  // -- ~/.gradle --
  const gradlePath = path.join(HOME, GRADLE_DIR);
  const gradleStat = safeStat(gradlePath);
  if (gradleStat && isOlderThanDays(gradleStat.mtimeMs, maxAgeDays)) {
    const sizeBytes = getDirSizeBytes(gradlePath);
    const sizeMb = Math.round((sizeBytes / (1024 * 1024)) * 100) / 100;
    if (sizeMb > 0.01) {
      if (removeDirRecursive(gradlePath, dryRun)) {
        items.push({
          path: gradlePath,
          size_mb: sizeMb,
          reason: `Dev artifact: .gradle older than ${maxAgeDays} days`,
        });
      } else {
        errors.push(`Failed to remove ${gradlePath}`);
      }
    }
  }
}

module.exports = { cleanDevArtifacts };
