const fs = require("fs");
const path = require("path");
const os = require("os");
const { execSync } = require("child_process");

const HOME = os.homedir();
const PAGE_SIZE = 4096;
const CMD_TIMEOUT = 10000;

function ensureDirectory(dirPath) {
  fs.mkdirSync(dirPath, { recursive: true });
}

function listWritableVolumeRoots() {
  const volumesRoot = "/Volumes";
  try {
    return fs.readdirSync(volumesRoot)
      .map((entry) => path.join(volumesRoot, entry))
      .filter((entry) => {
        try {
          return fs.statSync(entry).isDirectory();
        } catch {
          return false;
        }
      })
      .filter((entry) => !entry.startsWith("/Volumes/Macintosh HD"));
  } catch {
    return [];
  }
}

function isWritableDirectory(dirPath) {
  try {
    ensureDirectory(dirPath);
    const probe = path.join(dirPath, `.maccleaner-write-test-${process.pid}-${Date.now()}`);
    fs.writeFileSync(probe, "ok");
    fs.unlinkSync(probe);
    return true;
  } catch {
    return false;
  }
}

function resolveArchiveRoot(config) {
  const configured = String(config.iosBackupArchivePath || "").trim();
  if (configured && isWritableDirectory(configured)) {
    return configured;
  }

  const folderName = String(config.iosBackupArchiveFolderName || "MacCleaner Archive").trim() || "MacCleaner Archive";
  for (const volumeRoot of listWritableVolumeRoots()) {
    const candidate = path.join(volumeRoot, folderName);
    if (isWritableDirectory(candidate)) {
      return candidate;
    }
  }

  return null;
}

function buildArchiveDestination(archiveRoot, backup) {
  const safeDevice = String(backup.deviceName || "ios-backup")
    .replace(/[^a-z0-9._ -]+/gi, "")
    .trim()
    .replace(/\s+/g, "-")
    .slice(0, 60) || "ios-backup";
  const stamp = String(backup.date || new Date().toISOString()).replace(/[:]/g, "-");
  const archiveDir = path.join(archiveRoot, "iOS Backups");
  ensureDirectory(archiveDir);

  let destination = path.join(archiveDir, `${safeDevice}-${stamp}`);
  let suffix = 2;
  while (fs.existsSync(destination)) {
    destination = path.join(archiveDir, `${safeDevice}-${stamp}-${suffix}`);
    suffix += 1;
  }
  return destination;
}

/**
 * Run macOS built-in periodic maintenance scripts.
 * These scripts rotate logs, clean tmp dirs, rebuild locate/whatis DBs, etc.
 * The periodic command typically requires root, so we attempt it and fall back gracefully.
 */
function runPeriodicScripts(errors) {
  const result = { ranDaily: false, ranWeekly: false, ranMonthly: false, output: "" };

  try {
    const output = execSync("periodic daily weekly monthly 2>&1", {
      encoding: "utf-8",
      timeout: CMD_TIMEOUT,
    });
    result.ranDaily = true;
    result.ranWeekly = true;
    result.ranMonthly = true;
    result.output = output.trim();
  } catch (err) {
    const message = err.stderr
      ? err.stderr.toString().trim()
      : err.message || "Unknown error";
    result.output = "periodic scripts require elevated privileges or terminal access: " + message;
    if (errors) {
      errors.push("runPeriodicScripts: " + result.output);
    }
  }

  return result;
}

/**
 * Flush the macOS DNS resolver cache.
 * Uses dscacheutil -flushcache and killall -HUP mDNSResponder.
 * Both commands run without sudo on modern macOS.
 */
function flushDNSCache(errors) {
  const result = { success: false, method: "" };

  try {
    execSync("dscacheutil -flushcache 2>&1", {
      encoding: "utf-8",
      timeout: CMD_TIMEOUT,
    });
    result.method = "dscacheutil -flushcache";
    result.success = true;
  } catch (err) {
    const message = err.message || "dscacheutil failed";
    if (errors) {
      errors.push("flushDNSCache (dscacheutil): " + message);
    }
  }

  try {
    execSync("killall -HUP mDNSResponder 2>&1", {
      encoding: "utf-8",
      timeout: CMD_TIMEOUT,
    });
    result.method = result.success
      ? "dscacheutil -flushcache + killall -HUP mDNSResponder"
      : "killall -HUP mDNSResponder";
    result.success = true;
  } catch (err) {
    const message = err.message || "killall mDNSResponder failed";
    if (errors) {
      errors.push("flushDNSCache (mDNSResponder): " + message);
    }
  }

  return result;
}

/**
 * Parse vm_stat output to get memory statistics.
 * vm_stat reports page counts; multiply by page size (typically 4096) for bytes.
 */
function getMemoryStats() {
  const result = {
    totalBytes: 0,
    activeBytes: 0,
    freeBytes: 0,
    compressedBytes: 0,
    pressureLevel: "unknown",
  };

  try {
    const totalOutput = execSync("sysctl -n hw.memsize", {
      encoding: "utf-8",
      timeout: CMD_TIMEOUT,
    });
    result.totalBytes = parseInt(totalOutput.trim(), 10) || 0;
  } catch {
    // Cannot determine total memory
  }

  try {
    const vmOutput = execSync("vm_stat", { encoding: "utf-8", timeout: CMD_TIMEOUT });
    const lines = vmOutput.split("\n");

    const pageValues = {};
    for (const line of lines) {
      const match = line.match(/^(.+?):\s+([\d.]+)/);
      if (match) {
        const key = match[1].trim().toLowerCase();
        const value = parseInt(match[2], 10);
        if (!isNaN(value)) {
          pageValues[key] = value;
        }
      }
    }

    const freePages = pageValues["pages free"] || 0;
    const activePages = pageValues["pages active"] || 0;
    const inactivePages = pageValues["pages inactive"] || 0;
    const speculativePages = pageValues["pages speculative"] || 0;
    const compressedPages =
      pageValues["pages occupied by compressor"] ||
      pageValues["pages stored in compressor"] ||
      0;

    result.freeBytes = (freePages + speculativePages) * PAGE_SIZE;
    result.activeBytes = activePages * PAGE_SIZE;
    result.compressedBytes = compressedPages * PAGE_SIZE;

    // Determine pressure level based on free + inactive ratio
    if (result.totalBytes > 0) {
      const availableBytes = (freePages + inactivePages + speculativePages) * PAGE_SIZE;
      const ratio = availableBytes / result.totalBytes;
      if (ratio > 0.2) {
        result.pressureLevel = "normal";
      } else if (ratio > 0.08) {
        result.pressureLevel = "warn";
      } else {
        result.pressureLevel = "critical";
      }
    }
  } catch {
    // vm_stat not available
  }

  return result;
}

/**
 * Scan ~/Library/Application Support/MobileSync/Backup/ for iOS device backups.
 * Reads Info.plist from each backup folder to extract device name and date.
 */
function getIOSBackupStats() {
  const backupRoot = path.join(HOME, "Library", "Application Support", "MobileSync", "Backup");
  const result = { backups: [], totalSizeMb: 0 };

  let entries;
  try {
    entries = fs.readdirSync(backupRoot, { withFileTypes: true });
  } catch {
    return result;
  }

  for (const entry of entries) {
    if (!entry.isDirectory()) {
      continue;
    }

    const backupPath = path.join(backupRoot, entry.name);
    const backup = {
      path: backupPath,
      sizeMb: 0,
      deviceName: "Unknown Device",
      date: null,
    };

    // Get backup size
    try {
      const duOutput = execSync(`du -sk "${backupPath}" 2>/dev/null`, {
        encoding: "utf-8",
        timeout: CMD_TIMEOUT,
      });
      const kb = parseInt(duOutput.split("\t")[0], 10);
      if (!isNaN(kb)) {
        backup.sizeMb = Math.round((kb / 1024) * 100) / 100;
      }
    } catch {
      // Size unknown
    }

    // Read Info.plist for device name and date
    const plistPath = path.join(backupPath, "Info.plist");
    try {
      const plistXml = execSync(`plutil -convert xml1 -o - "${plistPath}" 2>/dev/null`, {
        encoding: "utf-8",
        timeout: CMD_TIMEOUT,
      });

      const nameMatch = plistXml.match(
        /<key>Device Name<\/key>\s*<string>([^<]+)<\/string>/
      );
      if (nameMatch) {
        backup.deviceName = nameMatch[1];
      }

      const dateMatch = plistXml.match(
        /<key>Last Backup Date<\/key>\s*<date>([^<]+)<\/date>/
      );
      if (dateMatch) {
        backup.date = dateMatch[1];
      }
    } catch {
      // Plist not readable; try stat for date fallback
      try {
        const stat = fs.statSync(backupPath);
        backup.date = stat.mtime.toISOString();
      } catch {
        // No date available
      }
    }

    result.backups.push(backup);
    result.totalSizeMb += backup.sizeMb;
  }

  result.totalSizeMb = Math.round(result.totalSizeMb * 100) / 100;
  result.backups.sort((a, b) => {
    const dateA = a.date ? new Date(a.date).getTime() : 0;
    const dateB = b.date ? new Date(b.date).getTime() : 0;
    return dateA - dateB;
  });

  return result;
}

/**
 * Clean iOS backups older than config.iosBackupMaxAgeDays (default 90 days).
 * In dry-run mode, items are recorded but nothing is deleted.
 */
function cleanOldIOSBackups(config, items, errors, dryRun) {
  const maxAgeDays = config.iosBackupMaxAgeDays || 90;
  const cutoff = Date.now() - maxAgeDays * 24 * 60 * 60 * 1000;
  const stats = getIOSBackupStats();
  const archiveMode = String(config.iosBackupArchiveMode || "if-available").trim().toLowerCase();
  const archiveRoot = archiveMode === "delete" ? null : resolveArchiveRoot(config);
  const archiveAvailable = Boolean(archiveRoot);

  for (const backup of stats.backups) {
    if (!backup.date) {
      continue;
    }

    const backupTime = new Date(backup.date).getTime();
    if (isNaN(backupTime) || backupTime >= cutoff) {
      continue;
    }

    const item = {
      path: backup.path,
      sizeMb: backup.sizeMb,
      reason: `iOS device backup older than ${maxAgeDays} days`,
      deviceName: backup.deviceName,
      backupDate: backup.date,
    };

    if (archiveAvailable) {
      item.reason += " — archive to external drive";
      if (!dryRun) {
        try {
          const destination = buildArchiveDestination(archiveRoot, backup);
          fs.renameSync(backup.path, destination);
          item.deleted = false;
          item.archived = true;
          item.archivePath = destination;
        } catch (err) {
          item.archived = false;
          item.error = err.message;
          if (errors) {
            errors.push("cleanOldIOSBackups archive: " + err.message);
          }
        }
      } else {
        item.deleted = false;
        item.archived = false;
        item.dryRun = true;
        item.archiveCandidate = buildArchiveDestination(archiveRoot, backup);
      }
    } else if (archiveMode === "if-available") {
      item.deleted = false;
      item.archived = false;
      item.skipped = true;
      item.reason += " — skipped because no writable external archive drive was found";
      if (!dryRun && errors) {
        errors.push(`cleanOldIOSBackups: skipped ${backup.deviceName || backup.path} because no writable external archive drive was found`);
      }
    } else {
      if (!dryRun) {
        try {
          fs.rmSync(backup.path, { recursive: true, force: true });
          item.deleted = true;
        } catch (err) {
          item.deleted = false;
          item.error = err.message;
          if (errors) {
            errors.push("cleanOldIOSBackups: " + err.message);
          }
        }
      } else {
        item.deleted = false;
        item.dryRun = true;
      }
    }

    items.push(item);
  }
}

module.exports = {
  runPeriodicScripts,
  flushDNSCache,
  getMemoryStats,
  getIOSBackupStats,
  cleanOldIOSBackups,
};
