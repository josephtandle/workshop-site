/**
 * Browser Cache Cleanup Module
 *
 * Standalone module for cleaning browser cache directories.
 * Targets: Chrome, Safari, Firefox, Brave, Arc
 * No external dependencies — Node.js built-ins only.
 */

const fs = require("fs");
const path = require("path");
const os = require("os");
const { execSync } = require("child_process");

const HOME = os.homedir();

const DEFAULT_MAX_AGE_DAYS = 7;
const LARGE_CACHE_THRESHOLD_MB = 200;

// Safety: only delete paths containing one of these segments
const SAFE_PATH_SEGMENTS = ["/Cache", "/cache2", "/GPUCache", "/LocalStorage", "/Code Cache"];

function isSafePath(dirPath) {
  return SAFE_PATH_SEGMENTS.some((seg) => dirPath.includes(seg));
}

function dirExists(dirPath) {
  try {
    return fs.statSync(dirPath).isDirectory();
  } catch {
    return false;
  }
}

function getDirSizeBytes(dirPath) {
  try {
    const result = execSync(`du -sk "${dirPath}" 2>/dev/null`, {
      encoding: "utf-8",
      timeout: 30000,
    });
    const kb = parseInt(result.split("\t")[0], 10);
    return isNaN(kb) ? 0 : kb * 1024;
  } catch {
    return 0;
  }
}

function getDirMtimeMs(dirPath) {
  try {
    return fs.statSync(dirPath).mtimeMs;
  } catch {
    return Date.now();
  }
}

function isOlderThanDays(mtimeMs, days) {
  const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
  return mtimeMs < cutoff;
}

function removeDirRecursive(dirPath) {
  try {
    fs.rmSync(dirPath, { recursive: true, force: true });
    return true;
  } catch {
    return false;
  }
}

/**
 * Check whether Library/Caches/<subdir> still exists.
 * If the parent cleaner already nuked it, we skip.
 */
function libraryCachesDirExists(subpath) {
  return dirExists(path.join(HOME, "Library", "Caches", subpath));
}

// Resolve all Firefox profile cache dirs.
// Scans baseRelPath for profile subdirs containing a cache2 folder.
function findFirefoxCacheDirs(baseRelPath) {
  const baseDir = path.join(HOME, baseRelPath);
  const results = [];
  if (!dirExists(baseDir)) return results;

  try {
    const profiles = fs.readdirSync(baseDir, { withFileTypes: true });
    for (const entry of profiles) {
      if (!entry.isDirectory()) continue;
      const cacheDir = path.join(baseDir, entry.name, "cache2");
      if (dirExists(cacheDir)) {
        results.push(cacheDir);
      }
    }
  } catch {
    // permission errors, etc.
  }
  return results;
}

// ── Browser definitions ────────────────────────────────────────────

function getChromePaths() {
  const base = "Library/Application Support/Google/Chrome/Default";
  return [
    { path: path.join(HOME, base, "Cache"), label: "Chrome Default Cache" },
    { path: path.join(HOME, base, "Code Cache"), label: "Chrome Code Cache" },
    { path: path.join(HOME, base, "GPUCache"), label: "Chrome GPUCache" },
    // Only include Library/Caches/Google/Chrome if it still exists
    // (the main cleaner may have already wiped Library/Caches subdirs)
    ...(libraryCachesDirExists("Google/Chrome")
      ? [{ path: path.join(HOME, "Library/Caches/Google/Chrome"), label: "Chrome Library Caches", skipIfParentCleaned: true }]
      : []),
  ];
}

function getSafariPaths() {
  return [
    { path: path.join(HOME, "Library/Caches/com.apple.Safari"), label: "Safari Caches" },
    { path: path.join(HOME, "Library/Safari/LocalStorage"), label: "Safari LocalStorage", ageOnly: true },
  ];
}

function getFirefoxPaths() {
  const results = [];
  for (const dir of findFirefoxCacheDirs("Library/Application Support/Firefox/Profiles")) {
    results.push({ path: dir, label: "Firefox profile cache" });
  }
  for (const dir of findFirefoxCacheDirs("Library/Caches/Firefox/Profiles")) {
    results.push({ path: dir, label: "Firefox Library Caches profile cache" });
  }
  return results;
}

function getBravePaths() {
  return [
    { path: path.join(HOME, "Library/Application Support/BraveSoftware/Brave-Browser/Default/Cache"), label: "Brave Default Cache" },
  ];
}

function getArcPaths() {
  return [
    { path: path.join(HOME, "Library/Application Support/Arc/User Data/Default/Cache"), label: "Arc Default Cache" },
  ];
}

// ── Core logic ─────────────────────────────────────────────────────

function shouldClean(dirPath, maxAgeDays, entry) {
  const sizeBytes = getDirSizeBytes(dirPath);
  const sizeMb = sizeBytes / (1024 * 1024);
  const mtimeMs = getDirMtimeMs(dirPath);

  // For LocalStorage entries, only clean by age
  if (entry && entry.ageOnly) {
    return isOlderThanDays(mtimeMs, maxAgeDays) ? { sizeMb, reason: `${entry.label} (older than ${maxAgeDays} days)` } : null;
  }

  // Large caches get cleaned regardless of age
  if (sizeMb > LARGE_CACHE_THRESHOLD_MB) {
    return { sizeMb, reason: `${entry ? entry.label : "cache"} (>${LARGE_CACHE_THRESHOLD_MB}MB)` };
  }

  // Otherwise clean if older than maxAgeDays
  if (isOlderThanDays(mtimeMs, maxAgeDays)) {
    return { sizeMb, reason: `${entry ? entry.label : "cache"} (older than ${maxAgeDays} days)` };
  }

  return null;
}

/**
 * Clean all browser caches based on config criteria.
 *
 * @param {object} config - Agent config (uses browserCacheMaxAgeDays)
 * @param {Array}  items  - Push cleaned items here: { path, size_mb, reason }
 * @param {Array}  errors - Push error messages here
 * @param {boolean} dryRun - If true, calculate but do not delete
 * @returns {{ totalFreedMb: number, itemCount: number }}
 */
function cleanBrowserCaches(config, items, errors, dryRun) {
  const maxAgeDays = config.browserCacheMaxAgeDays || DEFAULT_MAX_AGE_DAYS;
  let totalFreedMb = 0;
  let itemCount = 0;

  const allPaths = [
    ...getChromePaths(),
    ...getSafariPaths(),
    ...getFirefoxPaths(),
    ...getBravePaths(),
    ...getArcPaths(),
  ];

  for (const entry of allPaths) {
    const dirPath = entry.path;

    if (!dirExists(dirPath)) continue;

    // Safety: never delete anything without a recognized cache segment
    if (!isSafePath(dirPath)) {
      errors.push(`Safety check failed — skipping ${dirPath}`);
      continue;
    }

    try {
      const result = shouldClean(dirPath, maxAgeDays, entry);
      if (!result) continue;

      const { sizeMb, reason } = result;
      if (sizeMb < 0.01) continue;

      if (!dryRun) {
        if (removeDirRecursive(dirPath)) {
          items.push({ path: dirPath, size_mb: Math.round(sizeMb * 100) / 100, reason });
          totalFreedMb += sizeMb;
          itemCount++;
        } else {
          errors.push(`Failed to remove ${dirPath}`);
        }
      } else {
        items.push({ path: dirPath, size_mb: Math.round(sizeMb * 100) / 100, reason: `[DRY RUN] ${reason}` });
        totalFreedMb += sizeMb;
        itemCount++;
      }
    } catch (err) {
      errors.push(`${entry.label}: ${err.message}`);
    }
  }

  return { totalFreedMb: Math.round(totalFreedMb * 100) / 100, itemCount };
}

/**
 * Scan browser cache sizes without deleting anything.
 *
 * @returns {{ chrome: number, safari: number, firefox: number, brave: number, arc: number, total: number }}
 *          All values in MB, rounded to 2 decimals.
 */
function getBrowserCacheSize() {
  const result = { chrome: 0, safari: 0, firefox: 0, brave: 0, arc: 0, total: 0 };

  const browsers = {
    chrome: getChromePaths(),
    safari: getSafariPaths(),
    firefox: getFirefoxPaths(),
    brave: getBravePaths(),
    arc: getArcPaths(),
  };

  for (const [browser, paths] of Object.entries(browsers)) {
    let totalBytes = 0;
    for (const entry of paths) {
      if (dirExists(entry.path)) {
        totalBytes += getDirSizeBytes(entry.path);
      }
    }
    result[browser] = Math.round((totalBytes / (1024 * 1024)) * 100) / 100;
  }

  result.total = Math.round((result.chrome + result.safari + result.firefox + result.brave + result.arc) * 100) / 100;
  return result;
}

/**
 * Get detailed browser cache info with per-path breakdown.
 *
 * @returns {{ chrome: { sizeMb, paths }, safari: {...}, ... , totalMb }}
 */
function getBrowserCacheSizeDetailed() {
  const browsers = {
    chrome: getChromePaths(),
    safari: getSafariPaths(),
    firefox: getFirefoxPaths(),
    brave: getBravePaths(),
    arc: getArcPaths(),
  };

  const result = {};
  let totalMb = 0;

  for (const [browser, paths] of Object.entries(browsers)) {
    let browserTotal = 0;
    const foundPaths = [];

    for (const entry of paths) {
      if (dirExists(entry.path)) {
        const sizeBytes = getDirSizeBytes(entry.path);
        const sizeMb = Math.round((sizeBytes / (1024 * 1024)) * 100) / 100;
        browserTotal += sizeMb;
        foundPaths.push({ path: entry.path, sizeMb, label: entry.label });
      }
    }

    result[browser] = {
      sizeMb: Math.round(browserTotal * 100) / 100,
      paths: foundPaths,
    };
    totalMb += browserTotal;
  }

  return { browsers: result, totalMb: Math.round(totalMb * 100) / 100 };
}

module.exports = { cleanBrowserCaches, getBrowserCacheSize, getBrowserCacheSizeDetailed };
