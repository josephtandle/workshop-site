#!/usr/bin/env node

const fs = require("fs");
const os = require("os");
const path = require("path");
const { execFileSync } = require("child_process");

const DEFAULT_PORTS = [
  { port: 9224, label: "Personal Chrome" },
  { port: 9223, label: "Agent Chrome" },
];

function parseArgs(argv) {
  const args = { dryRun: false, configPath: null };
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === "--dry-run") {
      args.dryRun = true;
      continue;
    }
    if (arg === "--config" && argv[i + 1]) {
      args.configPath = argv[i + 1];
      i++;
    }
  }
  return args;
}

function loadConfig(configPath) {
  if (!configPath) return {};
  try {
    return JSON.parse(fs.readFileSync(configPath, "utf-8"));
  } catch {
    return {};
  }
}

function getPorts(configPath) {
  if (process.env.MC_CHROME_ORPHAN_PORTS) {
    try {
      const parsed = JSON.parse(process.env.MC_CHROME_ORPHAN_PORTS);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    } catch {
      // Fall back to config/defaults below.
    }
  }

  const config = loadConfig(configPath);
  if (Array.isArray(config.chromeOrphanPorts) && config.chromeOrphanPorts.length > 0) {
    return config.chromeOrphanPorts;
  }

  return DEFAULT_PORTS;
}

function closeChromeOrphans(options = {}) {
  const dryRun = Boolean(options.dryRun);
  const ports = getPorts(options.configPath);
  const items = [];
  const errors = [];

  for (const entry of ports) {
    const port = Number(entry.port);
    const label = entry.label || `Chrome ${port}`;

    if (!Number.isInteger(port) || port <= 0) {
      errors.push(`Invalid Chrome orphan port entry: ${JSON.stringify(entry)}`);
      continue;
    }

    try {
      const raw = execFileSync(
        "curl",
        ["-s", "--connect-timeout", "2", `http://localhost:${port}/json/list`],
        { encoding: "utf-8", timeout: 5000, maxBuffer: 1024 * 1024 }
      );
      let targets;
      try {
        targets = JSON.parse(raw);
      } catch {
        continue;
      }

      let closed = 0;
      for (const target of targets) {
        const title = (target.title || "").trim();
        const url = (target.url || "").trim();
        const type = target.type || "";

        if (type !== "page") continue;

        const isEmptyPage = !title && (!url || url === "about:blank" || url === "chrome://newtab/");
        const isOrphanedNav = !title && url && !url.startsWith("chrome") && !url.startsWith("http://localhost");

        if (!isEmptyPage && !isOrphanedNav) continue;

        if (!dryRun) {
          try {
            execFileSync(
              "curl",
              ["-s", "--connect-timeout", "2", `http://localhost:${port}/json/close/${target.id}`],
              { encoding: "utf-8", timeout: 3000, maxBuffer: 256 * 1024 }
            );
            closed++;
          } catch {
            // Ignore individual close failures.
          }
        } else {
          closed++;
        }
      }

      if (closed > 0) {
        items.push({
          path: `${label} (port ${port})`,
          size_mb: closed * 50,
          reason: `Closed ${closed} empty/orphaned Chrome targets`,
        });
      }
    } catch {
      // Chrome not running on this port.
    }
  }

  return { items, errors };
}

if (require.main === module) {
  const args = parseArgs(process.argv.slice(2));
  const fallbackConfigPath = path.join(os.homedir(), ".maccleaner", "config.json");
  const result = closeChromeOrphans({
    dryRun: args.dryRun,
    configPath: args.configPath || process.env.MC_CONFIG_FILE || fallbackConfigPath,
  });
  process.stdout.write(JSON.stringify(result));
} else {
  module.exports = {
    closeChromeOrphans,
  };
}
