/**
 * Dev Artifacts Scanner — lightweight dry-run scan (no deletions)
 *
 * Used by the preview API to show what dev artifacts exist and their sizes.
 *
 * Usage:
 *   const { scanDevArtifacts } = require("./dev-artifacts-scan");
 *   const artifacts = scanDevArtifacts(config);
 */

const fs = require("fs");
const path = require("path");
const os = require("os");
const { execSync } = require("child_process");

const HOME = os.homedir();

const SCAN_ROOTS = [
  path.join(HOME, "Documents"),
  path.join(HOME, "Desktop"),
  path.join(HOME, "code"),
  path.join(HOME, "projects"),
  path.join(HOME, "src"),
  path.join(HOME, "workspace"),
  path.join(HOME, "Developer"),
];

const NODE_MODULES = "node_modules";
const PYTHON_VENVS = [".venv", "venv", "env"];
const PYCACHE = "__pycache__";
const RUST_TARGET = "target";
const GRADLE_DIR = ".gradle";

const PYCACHE_MIN_BYTES = 10 * 1024 * 1024;

function getDirSizeBytes(dirPath) {
  try {
    const result = execSync(`du -sk "${dirPath}" 2>/dev/null`, {
      encoding: "utf-8",
      timeout: 30000,
    });
    const kb = parseInt(result.split("\t")[0], 10);
    return isNaN(kb) ? 0 : kb * 1024;
  } catch {
    return 0;
  }
}

function safeStat(p) {
  try {
    return fs.statSync(p);
  } catch {
    return null;
  }
}

function safeReaddir(p) {
  try {
    return fs.readdirSync(p, { withFileTypes: true });
  } catch {
    return [];
  }
}

function isProtectedPath(p) {
  return p.includes(".myos");
}

function ageDays(mtimeMs) {
  return Math.round((Date.now() - mtimeMs) / (24 * 60 * 60 * 1000));
}

function walkDirs(root, maxDepth, visitor) {
  if (maxDepth < 0) return;
  const entries = safeReaddir(root);
  for (const entry of entries) {
    if (!entry.isDirectory()) continue;
    const fullPath = path.join(root, entry.name);
    if (isProtectedPath(fullPath)) continue;
    visitor(fullPath, entry.name, root);
    if (maxDepth > 0) {
      walkDirs(fullPath, maxDepth - 1, visitor);
    }
  }
}

function classifyType(name, parentDir) {
  if (name === NODE_MODULES) return "node_modules";
  if (PYTHON_VENVS.includes(name)) return "python_venv";
  if (name === RUST_TARGET) return "rust_target";
  if (name === PYCACHE) return "pycache";
  if (name === GRADLE_DIR) return "gradle";
  return "unknown";
}

/**
 * Scan for dev artifacts and return an array of found items (no deletion).
 *
 * @param {object} config - mac-cleaner config
 * @returns {Array<{path: string, size_mb: number, type: string, ageDays: number}>}
 */
function scanDevArtifacts(config) {
  const maxAgeDays = config.devArtifactsMaxAgeDays || 30;
  const artifacts = [];

  for (const root of SCAN_ROOTS) {
    if (!safeStat(root)) continue;

    walkDirs(root, 3, (fullPath, name, parentDir) => {
      // node_modules
      if (name === NODE_MODULES) {
        const stat = safeStat(fullPath);
        if (!stat) return;
        const age = ageDays(stat.mtimeMs);
        if (age < maxAgeDays) return;
        const sizeBytes = getDirSizeBytes(fullPath);
        artifacts.push({
          path: fullPath,
          size_mb: Math.round((sizeBytes / (1024 * 1024)) * 100) / 100,
          type: "node_modules",
          ageDays: age,
        });
        return;
      }

      // Python venvs
      if (PYTHON_VENVS.includes(name)) {
        const hasCfg =
          safeStat(path.join(fullPath, "pyvenv.cfg")) ||
          safeStat(path.join(fullPath, "bin", "activate"));
        if (!hasCfg) return;
        const stat = safeStat(fullPath);
        if (!stat) return;
        const age = ageDays(stat.mtimeMs);
        if (age < maxAgeDays) return;
        const sizeBytes = getDirSizeBytes(fullPath);
        artifacts.push({
          path: fullPath,
          size_mb: Math.round((sizeBytes / (1024 * 1024)) * 100) / 100,
          type: "python_venv",
          ageDays: age,
        });
        return;
      }

      // Rust target/
      if (name === RUST_TARGET) {
        const cargoToml = path.join(parentDir, "Cargo.toml");
        if (!safeStat(cargoToml)) return;
        const stat = safeStat(fullPath);
        if (!stat) return;
        const age = ageDays(stat.mtimeMs);
        if (age < maxAgeDays) return;
        const sizeBytes = getDirSizeBytes(fullPath);
        artifacts.push({
          path: fullPath,
          size_mb: Math.round((sizeBytes / (1024 * 1024)) * 100) / 100,
          type: "rust_target",
          ageDays: age,
        });
        return;
      }

      // __pycache__
      if (name === PYCACHE) {
        const sizeBytes = getDirSizeBytes(fullPath);
        if (sizeBytes < PYCACHE_MIN_BYTES) return;
        const stat = safeStat(fullPath);
        if (!stat) return;
        const age = ageDays(stat.mtimeMs);
        if (age < maxAgeDays) return;
        artifacts.push({
          path: fullPath,
          size_mb: Math.round((sizeBytes / (1024 * 1024)) * 100) / 100,
          type: "pycache",
          ageDays: age,
        });
        return;
      }
    });
  }

  // ~/.gradle
  const gradlePath = path.join(HOME, GRADLE_DIR);
  const gradleStat = safeStat(gradlePath);
  if (gradleStat) {
    const age = ageDays(gradleStat.mtimeMs);
    if (age >= maxAgeDays) {
      const sizeBytes = getDirSizeBytes(gradlePath);
      if (sizeBytes > 0) {
        artifacts.push({
          path: gradlePath,
          size_mb: Math.round((sizeBytes / (1024 * 1024)) * 100) / 100,
          type: "gradle",
          ageDays: age,
        });
      }
    }
  }

  return artifacts;
}

module.exports = { scanDevArtifacts };
