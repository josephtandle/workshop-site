# MacCleaner Script

A student-safe macOS cleanup script.

This package is script-first, not app-first. It is meant to be run from Terminal with a preview-first workflow.

## Safety Defaults

- Running `maccleaner` shows a dry-run preview by default.
- Real cleanup only runs with `--confirm-clean`.
- Old iOS backups archive to a writable external drive when one is available.
- If no writable external archive drive is found, those old iOS backups are previewed and skipped.
- Telegram reporting is disabled by default.

## Usage

```bash
node maccleaner.js
```

Safe preview:

```bash
maccleaner
```

Real cleanup after review:

```bash
maccleaner --confirm-clean
```

## Install From A Clone

```bash
git clone git@github.com:josephtandle/maccleaner.git
cd maccleaner
./install.sh
```

This installs the script into:

- code: `~/.local/share/maccleaner/`
- launcher: `~/bin/maccleaner`
- config: `~/.maccleaner/config.json`

## External Drive Behavior

Default config:

- `iosBackupArchiveMode: "if-available"`
- `iosBackupArchivePath: ""`
- `iosBackupArchiveFolderName: "MacCleaner Archive"`

If `iosBackupArchivePath` is blank, the script tries to find a writable external volume and creates `MacCleaner Archive/iOS Backups/` there. If none is available, old iOS backups are left untouched and only shown in preview.

## Local Data

```text
~/.maccleaner/
  config.json
  data/
    preview.json
    last-run.json
    history.json
    lifetime-stats.json
```

## Requirements

- macOS
- Node.js

## License

MIT
