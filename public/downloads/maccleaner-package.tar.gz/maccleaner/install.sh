#!/usr/bin/env bash
set -euo pipefail

[[ "$(uname)" == "Darwin" ]] || { echo "MacCleaner only runs on macOS."; exit 1; }
command -v node >/dev/null 2>&1 || { echo "Node.js is required."; exit 1; }

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_ROOT="${HOME}/.local/share/maccleaner"
BIN_DIR="${HOME}/bin"
CONFIG_ROOT="${HOME}/.maccleaner"
CONFIG_FILE="${CONFIG_ROOT}/config.json"

mkdir -p "${INSTALL_ROOT}" "${BIN_DIR}" "${CONFIG_ROOT}"
rsync -a --delete \
  --exclude '.git' \
  --exclude 'node_modules' \
  "${REPO_ROOT}/" "${INSTALL_ROOT}/"

if [[ ! -f "${CONFIG_FILE}" ]]; then
  cp "${INSTALL_ROOT}/bundled-src/default-config.json" "${CONFIG_FILE}"
fi

cat > "${BIN_DIR}/maccleaner" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
exec node "$HOME/.local/share/maccleaner/maccleaner.js" "$@"
EOF
chmod +x "${BIN_DIR}/maccleaner"

echo "Installed MacCleaner script."
echo "Run a safe preview with: maccleaner"
echo "Run a real cleanup with: maccleaner --confirm-clean"
