#!/usr/bin/env node
"use strict";

const path = require("path");
const { spawnSync } = require("child_process");

const backend = path.join(__dirname, "bundled-src", "index.js");
const args = process.argv.slice(2);

if (args.includes("--help") || args.includes("-h")) {
  process.stdout.write(
    [
      "MacCleaner",
      "",
      "Usage:",
      "  maccleaner                 Safe preview only",
      "  maccleaner --dry-run       Explicit preview",
      "  maccleaner --confirm-clean Apply cleanup after review",
      "",
      "Config:",
      "  ~/.maccleaner/config.json",
    ].join("\n") + "\n"
  );
  process.exit(0);
}

const result = spawnSync(process.execPath, [backend, ...args], {
  stdio: "inherit",
  env: process.env,
});

if (result.error) {
  console.error(result.error.message);
  process.exit(1);
}

process.exit(result.status == null ? 1 : result.status);
