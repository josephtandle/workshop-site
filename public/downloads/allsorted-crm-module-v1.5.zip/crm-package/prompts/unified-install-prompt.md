Open this folder and install the AllSorted CRM module into my existing Mission Control build.

You must keep going until the install is complete, tested, and working unless you hit a true blocker.

Your job:

1. Detect whether you are on macOS or Windows and adapt commands accordingly.
2. Locate my existing Mission Control repo automatically.
   - First check the current working directory.
   - If it is not Mission Control, search nearby for a repo with:
     - `package.json`
     - `app/app/layout.tsx` or similar
     - `app/api`
     - `lib`
3. Verify the repo before editing anything.
4. Back up every CRM-related file you change.
5. Run the packaged installer:
   - `node crm-package/install/install-crm-module.js --target "<MISSION_CONTROL_PATH>"`
6. If dependencies are missing, install whatever is needed.
   - Prefer the repo's own package manager if a lockfile exists.
   - If native packages fail, keep troubleshooting instead of stopping immediately.
7. Search for existing Resend configuration in:
   - target `.env.local`
   - target `.env`
   - nearby workspace env files
   - `RESEND_API_KEY`
   - `RESEND_FROM_EMAIL`
8. If a Resend key exists, wire CRM email automatically.
9. If Resend is missing, do not block install.
   - Finish the install anyway.
   - Leave email disabled.
   - Print exact next steps to enable it later.
10. Seed the included sample CRM data.
    - Preserve any existing CRM data.
    - Do not overwrite student records.
11. Start or restart Mission Control if needed.
12. Run validation:
    - `node crm-package/install/validate-crm-install.js --target "<MISSION_CONTROL_PATH>" --base-url "http://127.0.0.1:3000"`
13. If validation fails, debug and fix the install, then run validation again.
14. Only when validation passes, print a completion message that clearly says:
    - CRM installed correctly
    - target path
    - whether Resend was auto-wired
    - that sample data is available
    - which tests passed

Hard blockers:

- no valid Mission Control repo can be found
- the repo is not writable
- the app structure is too broken to patch safely

When you report success, keep it concrete. Say exactly what you changed and what you verified.
