# AllSorted CRM Module

Portable CRM package built from the GoldenClaw Mission Control CRM for Mastermind students who already have Mission Control running on port `3000`.

## What this package contains

- `module/mission-control/`
  Sanitized CRM files copied from GoldenClaw.
- `module/seed/crm-sample.db`
  GoldenClaw sample CRM database snapshot with starter templates and disabled starter automations.
- `install/install-crm-module.js`
  Idempotent installer for an existing Mission Control repo.
- `install/validate-crm-install.js`
  Post-install file and runtime validator.
- `prompts/unified-install-prompt.md`
  Single Claude/Codex-friendly installer prompt for Mac and Windows.

## Common commands

```bash
node crm-package/build-module.js
node crm-package/install/install-crm-module.js --target /path/to/mission-control
node crm-package/install/validate-crm-install.js --target /path/to/mission-control --base-url http://127.0.0.1:3000
node crm-package/package-release.js
```

## Release artifact

Running `package-release.js` creates:

- `crm-package/dist/allsorted-crm-module-v1.5.zip`
- `crm-package/dist/allsorted-crm-module-v1.5.zip.sha256`
