import ViewsPanel from "../_components/ViewsPanel";

export default function CrmViewsPage() {
  return <ViewsPanel />;
}
