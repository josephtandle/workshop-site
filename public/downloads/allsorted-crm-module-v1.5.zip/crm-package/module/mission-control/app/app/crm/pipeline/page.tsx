import { CrmWorkspace } from "../_components/CrmWorkspace";

const crm = require("../../../../lib/crm");

export default function CrmPipelinePage() {
  const board = crm.getPipelineBoard({ project: "mastermind" });
  const projectCatalog = crm.getProjectCatalog().map((project: { name: string }) => project.name);
  const affiliates = crm.listMastermindAffiliates();

  return (
    <CrmWorkspace
      mode="pipeline"
      initialPipelineData={{
        grouped: board?.grouped || {},
        statuses: board?.statuses || [],
        allStatuses: board?.allStatuses || [],
        projectCatalog,
        affiliates,
        columnAutomationMap: board?.stageAutomationMap || {},
        summary: board?.summary || {},
      }}
    />
  );
}
