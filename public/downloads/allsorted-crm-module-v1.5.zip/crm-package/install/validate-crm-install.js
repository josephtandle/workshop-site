#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");

function parseArgs(argv) {
  const args = {};
  for (let i = 0; i < argv.length; i += 1) {
    if (argv[i] === "--target") args.target = argv[++i];
    else if (argv[i] === "--base-url") args.baseUrl = argv[++i];
  }
  return args;
}

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

async function checkUrl(url) {
  const res = await fetch(url);
  const body = await res.text();
  if (!res.ok) {
    throw new Error(`${url} returned HTTP ${res.status}: ${body.slice(0, 200)}`);
  }
  return body;
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const targetDir = path.resolve(args.target || process.cwd());
  const baseUrl = args.baseUrl || "http://127.0.0.1:3000";

  const requiredFiles = [
    "app/app/crm/layout.tsx",
    "app/app/crm/affiliates/page.tsx",
    "app/app/crm/connection-map/page.tsx",
    "app/app/crm/inbox/page.tsx",
    "app/app/crm/labels/page.tsx",
    "app/app/crm/pipeline/page.tsx",
    "app/app/crm/templates/page.tsx",
    "app/app/crm/automations/page.tsx",
    "app/app/crm/settings/page.tsx",
    "app/app/crm/views/page.tsx",
    "app/api/crm/route.ts",
    "app/api/crm/pipeline/route.ts",
    "lib/crm.js",
    "lib/crm-enrichment.js",
  ];

  for (const relativePath of requiredFiles) {
    assert(fs.existsSync(path.join(targetDir, relativePath)), `Missing required file: ${relativePath}`);
  }

  const layoutSource = fs.readFileSync(path.join(targetDir, "app/app/layout.tsx"), "utf8");
  assert(layoutSource.includes("/app/crm"), "Main app layout does not include a CRM nav link");

  const crmSource = fs.readFileSync(path.join(targetDir, "lib/crm.js"), "utf8");
  assert(
    crmSource.includes("email_subscription_status, created_at, updated_at"),
    "lib/crm.js is missing the crm_sync_destinations NOT NULL timestamp fix"
  );
  assert(
    crmSource.includes("campaign, keyword, raw_payload, captured_at, created_at"),
    "lib/crm.js is missing the crm_lead_events created_at fix"
  );

  const routes = [
    `${baseUrl}/app/crm`,
    `${baseUrl}/app/crm/pipeline`,
    `${baseUrl}/app/crm/templates`,
    `${baseUrl}/app/crm/automations`,
    `${baseUrl}/app/crm/settings`,
    `${baseUrl}/api/crm?view=pipeline&project=mastermind`,
    `${baseUrl}/api/crm/pipeline?project=mastermind`,
  ];

  for (const route of routes) {
    await checkUrl(route);
  }

  console.log("[crm-package] Validation passed");
}

main().catch((error) => {
  console.error(`[crm-package] Validation failed: ${error.message}`);
  process.exit(1);
});
