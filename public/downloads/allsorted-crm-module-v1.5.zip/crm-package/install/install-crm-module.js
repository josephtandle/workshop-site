#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const os = require("os");
const { execFileSync, spawn } = require("child_process");

const PACKAGE_ROOT = path.resolve(__dirname, "..");
const MODULE_ROOT = path.join(PACKAGE_ROOT, "module", "mission-control");
const SAMPLE_DB = path.join(PACKAGE_ROOT, "module", "seed", "crm-sample.db");
const VERSION = "1.5";

function parseArgs(argv) {
  const args = { installDeps: true, importSamples: true };
  for (let i = 0; i < argv.length; i += 1) {
    const token = argv[i];
    if (token === "--target") args.target = argv[++i];
    else if (token === "--skip-install") args.installDeps = false;
    else if (token === "--skip-samples") args.importSamples = false;
    else if (token === "--port") args.port = argv[++i];
  }
  return args;
}

function ensureDir(dirPath) {
  fs.mkdirSync(dirPath, { recursive: true });
}

function readJson(filePath) {
  return JSON.parse(fs.readFileSync(filePath, "utf8"));
}

function writeJson(filePath, value) {
  fs.writeFileSync(filePath, `${JSON.stringify(value, null, 2)}\n`, "utf8");
}

function pathExists(filePath) {
  try {
    fs.accessSync(filePath);
    return true;
  } catch {
    return false;
  }
}

function resolveTargetDir(explicitTarget) {
  const candidates = [];
  if (explicitTarget) candidates.push(path.resolve(explicitTarget));

  let cursor = process.cwd();
  for (let i = 0; i < 5; i += 1) {
    candidates.push(cursor);
    const parent = path.dirname(cursor);
    if (parent === cursor) break;
    cursor = parent;
  }

  const childHints = [
    "mission-control",
    "MissionControl",
    "mission_control",
  ];
  const scanRoots = Array.from(new Set(candidates));
  for (const root of scanRoots) {
    for (const hint of childHints) {
      candidates.push(path.join(root, hint));
    }
  }

  for (const candidate of candidates) {
    if (looksLikeMissionControlRepo(candidate)) return candidate;
  }
  throw new Error("Could not find an existing Mission Control repo. Re-run with --target /path/to/mission-control.");
}

function looksLikeMissionControlRepo(targetDir) {
  if (!targetDir || !pathExists(targetDir)) return false;
  const packageJson = path.join(targetDir, "package.json");
  const hasLayout =
    pathExists(path.join(targetDir, "app", "app", "layout.tsx")) ||
    pathExists(path.join(targetDir, "app", "app", "layout.jsx")) ||
    pathExists(path.join(targetDir, "app", "app", "layout.js"));
  return pathExists(packageJson) && hasLayout && pathExists(path.join(targetDir, "app", "api")) && pathExists(path.join(targetDir, "lib"));
}

function backupFile(sourcePath, backupRoot, targetRoot) {
  if (!pathExists(sourcePath)) return;
  const relativePath = path.relative(targetRoot, sourcePath);
  const backupPath = path.join(backupRoot, relativePath);
  ensureDir(path.dirname(backupPath));
  fs.copyFileSync(sourcePath, backupPath);
}

function copyModuleFiles(targetDir, backupRoot) {
  const stack = [MODULE_ROOT];
  while (stack.length) {
    const current = stack.pop();
    const entries = fs.readdirSync(current, { withFileTypes: true });
    for (const entry of entries) {
      const sourcePath = path.join(current, entry.name);
      const relativePath = path.relative(MODULE_ROOT, sourcePath);
      const destPath = path.join(targetDir, relativePath);
      if (entry.isDirectory()) {
        ensureDir(destPath);
        stack.push(sourcePath);
      } else {
        backupFile(destPath, backupRoot, targetDir);
        ensureDir(path.dirname(destPath));
        fs.copyFileSync(sourcePath, destPath);
      }
    }
  }
}

function upsertPackageJson(targetDir) {
  const packageJsonPath = path.join(targetDir, "package.json");
  const pkg = readJson(packageJsonPath);
  pkg.scripts = pkg.scripts || {};
  pkg.dependencies = pkg.dependencies || {};

  if (!pkg.scripts["seed:crm-demo"]) {
    pkg.scripts["seed:crm-demo"] = "node seed-crm-demo-data.js";
  }
  if (!pkg.dependencies["better-sqlite3"]) {
    pkg.dependencies["better-sqlite3"] = "^12.6.2";
  }
  if (!pkg.dependencies["lucide-react"]) {
    pkg.dependencies["lucide-react"] = "^0.408.0";
  }

  writeJson(packageJsonPath, pkg);
}

function patchLayoutFile(layoutPath) {
  const source = fs.readFileSync(layoutPath, "utf8");
  if (source.includes('href: "/app/crm"') || source.includes('href="/app/crm"')) {
    return "already-present";
  }

  let updated = source;

  if (source.includes("const NAV_SECTIONS")) {
    updated = source.replace(
      '{ href: "/app/projects", label: "File Browser", icon: FolderOpen },',
      '{ href: "/app/projects", label: "File Browser", icon: FolderOpen },\n      { href: "/app/crm", label: "CRM", icon: KanbanSquare },'
    );
  } else if (source.includes("const ALL_ITEMS: NavItem[] = [")) {
    updated = source.replace(
      '{ name: "File Browser",   href: "/app/projects",       icon: FolderOpen },',
      '{ name: "File Browser",   href: "/app/projects",       icon: FolderOpen },\n  { name: "CRM",            href: "/app/crm",            icon: Users },'
    );
  }

  if (updated !== source) {
    fs.writeFileSync(layoutPath, updated, "utf8");
    return "patched";
  }
  return "unpatched";
}

function patchNav(targetDir, backupRoot) {
  const candidatePaths = [
    path.join(targetDir, "app", "app", "layout.tsx"),
    path.join(targetDir, "app", "app", "layout.jsx"),
    path.join(targetDir, "app", "app", "layout.js"),
  ].filter(pathExists);

  for (const layoutPath of candidatePaths) {
    backupFile(layoutPath, backupRoot, targetDir);
    const result = patchLayoutFile(layoutPath);
    if (result === "patched" || result === "already-present") return;
  }
  throw new Error("Could not patch the Mission Control nav layout automatically.");
}

function detectEnvFiles(targetDir) {
  const repoParent = path.dirname(targetDir);
  return [
    path.join(targetDir, ".env.local"),
    path.join(targetDir, ".env"),
    path.join(repoParent, ".env.local"),
    path.join(repoParent, ".env"),
  ].filter(pathExists);
}

function parseEnv(content) {
  const values = {};
  for (const line of content.split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (!match) continue;
    const key = match[1];
    let value = match[2];
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    values[key] = value;
  }
  return values;
}

function detectResendConfig(targetDir) {
  const values = {};
  for (const filePath of detectEnvFiles(targetDir)) {
    Object.assign(values, parseEnv(fs.readFileSync(filePath, "utf8")));
  }
  return {
    apiKey: values.RESEND_API_KEY || "",
    fromEmail:
      values.RESEND_FROM_EMAIL ||
      values.CRM_RESEND_FROM_EMAIL ||
      values.CRM_DEFAULT_FROM_EMAIL ||
      "",
  };
}

function ensureWorkspaceDataDir(targetDir) {
  const workspacePath = process.env.CRM_WORKSPACE_PATH || path.resolve(targetDir, "..");
  const dataDir = path.join(workspacePath, "data");
  ensureDir(dataDir);
  return { workspacePath, dataDir };
}

function createSeedScript(targetDir) {
  const localAssetDir = path.join(targetDir, ".allsorted-crm-package");
  ensureDir(localAssetDir);
  fs.copyFileSync(SAMPLE_DB, path.join(localAssetDir, "crm-sample.db"));
  const content = `#!/usr/bin/env node
"use strict";
const path = require("path");
const { importSampleDbIntoTarget } = require("./install/install-crm-module.js");
const targetDir = process.cwd();
importSampleDbIntoTarget({
  targetDir,
  sampleDbPath: path.join(targetDir, ".allsorted-crm-package", "crm-sample.db"),
  resendConfig: { apiKey: process.env.RESEND_API_KEY || "", fromEmail: process.env.RESEND_FROM_EMAIL || "" },
});
console.log("[crm-package] CRM demo sample import complete");
`;
  fs.writeFileSync(path.join(targetDir, "seed-crm-demo-data.js"), content, "utf8");
}

function sqlite(targetDbPath, sql, attachDbPath) {
  const args = [targetDbPath];
  if (attachDbPath) {
    args.push(`ATTACH DATABASE '${attachDbPath.replace(/'/g, "''")}' AS sample; ${sql}`);
  } else {
    args.push(sql);
  }
  execFileSync("sqlite3", args, { stdio: "inherit" });
}

function listTables(dbPath) {
  return execFileSync(
    "sqlite3",
    [dbPath, "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;"],
    { encoding: "utf8" }
  )
    .split(/\r?\n/)
    .map((entry) => entry.trim())
    .filter(Boolean);
}

function listColumns(dbPath, tableName) {
  return execFileSync(
    "sqlite3",
    [dbPath, `PRAGMA table_info('${tableName.replace(/'/g, "''")}');`],
    { encoding: "utf8" }
  )
    .split(/\r?\n/)
    .map((row) => row.trim())
    .filter(Boolean)
    .map((row) => row.split("|")[1])
    .filter(Boolean);
}

function importSampleDbIntoTarget({ targetDir, sampleDbPath, resendConfig }) {
  const { dataDir } = ensureWorkspaceDataDir(targetDir);
  const targetDbPath = path.join(dataDir, "crm.db");
  const hasCrmContactsTable =
    pathExists(targetDbPath) &&
    (() => {
      try {
        const result = execFileSync(
          "sqlite3",
          [targetDbPath, "SELECT name FROM sqlite_master WHERE type='table' AND name='crm_contacts';"],
          { encoding: "utf8" }
        ).trim();
        return result === "crm_contacts";
      } catch {
        return false;
      }
    })();

  if (!pathExists(targetDbPath) || !hasCrmContactsTable) {
    fs.copyFileSync(sampleDbPath, targetDbPath);
  } else {
    const targetTables = new Set(listTables(targetDbPath));
    const sampleTables = listTables(sampleDbPath);
    const importTables = sampleTables.filter((table) => targetTables.has(table) && table !== "sqlite_sequence");
    const statements = importTables
      .map((table) => {
        const targetColumns = new Set(listColumns(targetDbPath, table));
        const sampleColumns = listColumns(sampleDbPath, table);
        const sharedColumns = sampleColumns.filter((column) => targetColumns.has(column));
        if (!sharedColumns.length) return "";
        const columnList = sharedColumns.join(", ");
        return `INSERT OR IGNORE INTO ${table} (${columnList}) SELECT ${columnList} FROM sample.${table};`;
      })
      .filter(Boolean)
      .join(" ");
    sqlite(targetDbPath, statements, sampleDbPath);
  }

  const updates = [];
  if (resendConfig.apiKey) {
    updates.push("INSERT INTO crm_settings(key, value) VALUES ('crm.automation.email.live_enabled', json('true')) ON CONFLICT(key) DO UPDATE SET value = excluded.value;");
  }
  if (resendConfig.fromEmail) {
    const fromValue = `All Sorted CRM <${resendConfig.fromEmail}>`;
    updates.push(`INSERT INTO crm_settings(key, value) VALUES ('crm.automation.email.from_address', json_quote('${fromValue.replace(/'/g, "''")}')) ON CONFLICT(key) DO UPDATE SET value = excluded.value;`);
  }
  if (updates.length) {
    sqlite(targetDbPath, updates.join(" "));
  }
}

function detectPackageManager(targetDir) {
  if (pathExists(path.join(targetDir, "pnpm-lock.yaml"))) return { cmd: "pnpm", args: ["install"] };
  if (pathExists(path.join(targetDir, "yarn.lock"))) return { cmd: "yarn", args: ["install"] };
  return { cmd: "npm", args: ["install"] };
}

function installDependencies(targetDir) {
  const pkgManager = detectPackageManager(targetDir);
  execFileSync(pkgManager.cmd, pkgManager.args, { cwd: targetDir, stdio: "inherit" });
}

function printSummary(targetDir, resendConfig) {
  const lines = [
    `[crm-package] Installed AllSorted CRM Module v${VERSION}`,
    `[crm-package] Target: ${targetDir}`,
    `[crm-package] Sample data: installed`,
    `[crm-package] Resend: ${resendConfig.apiKey ? "detected and wired" : "not found; email left disabled"}`,
  ];
  console.log(lines.join("\n"));
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  const targetDir = resolveTargetDir(args.target);
  const backupRoot = path.join(targetDir, ".allsorted-crm-backups", new Date().toISOString().replace(/[:.]/g, "-"));
  ensureDir(backupRoot);

  copyModuleFiles(targetDir, backupRoot);
  upsertPackageJson(targetDir);
  patchNav(targetDir, backupRoot);
  createSeedScript(targetDir);

  const resendConfig = detectResendConfig(targetDir);
  if (args.importSamples) {
    importSampleDbIntoTarget({ targetDir, sampleDbPath: SAMPLE_DB, resendConfig });
  }
  if (args.installDeps) {
    installDependencies(targetDir);
  }

  printSummary(targetDir, resendConfig);
}

if (require.main === module) {
  main();
}

module.exports = {
  importSampleDbIntoTarget,
};
