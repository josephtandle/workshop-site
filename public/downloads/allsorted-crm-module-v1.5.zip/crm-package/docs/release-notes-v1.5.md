# AllSorted CRM Module v1.5

## Included

- GoldenClaw CRM pipeline, contacts, templates, automations, approval, and settings surfaces
- main Mission Control nav integration
- GoldenClaw sample CRM dataset
- starter email templates
- starter email automations installed but disabled by default
- Resend auto-detection during install
- installer and validator scripts
- CRM enrichment actions and bundled `lib/crm-enrichment.js`
- `Enrich All` in CRM list surfaces and `Enrich This Lead` in the lead modal
- readable CRM metadata cleanup from the latest GoldenClaw CRM pass

## Student install outcome

- CRM route added to existing Mission Control on port `3000`
- sample leads available immediately
- email capability auto-wired if existing Resend env is found
- no overwrite of existing CRM records during install
- enrichment tooling included in the package build

## Release host

- Private GitHub release asset attached to `josephtandle/allsorted-web`
