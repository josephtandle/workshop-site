# AllSorted CRM Module v0.1.0

## Included

- GoldenClaw CRM pipeline, contacts, templates, automations, approval, and settings surfaces
- main Mission Control nav integration
- GoldenClaw sample CRM dataset
- starter email templates
- starter email automations installed but disabled by default
- Resend auto-detection during install
- installer and validator scripts

## Student install outcome

- CRM route added to existing Mission Control on port `3000`
- sample leads available immediately
- email capability auto-wired if existing Resend env is found
- no overwrite of existing CRM records

## Release host

- Private GitHub release asset attached to `josephtandle/allsorted-web`

