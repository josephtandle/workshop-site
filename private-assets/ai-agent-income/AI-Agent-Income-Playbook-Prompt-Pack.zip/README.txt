The AI Agent Income Playbook by Joe Che

Use index.txt to choose a lane. Start with its Starter prompt.
Open the prompt .txt file and copy everything in it.
Open a fresh Claude Code session in an empty folder and paste what you copied.
Answer its questions, then follow the steps and review the results.
Use the Upgrade prompt when you are ready to improve that lane.
